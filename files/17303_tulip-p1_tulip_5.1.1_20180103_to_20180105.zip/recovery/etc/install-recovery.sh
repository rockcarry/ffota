#!/system/bin/sh
if ! applypatch -c EMMC:/dev/block/by-name/recovery:8425472:3929088a778a100c6f8bf1664dee9ebeee8940cd; then
  log -t recovery "Installing new recovery image"
  applypatch -b /system/etc/recovery-resource.dat EMMC:/dev/block/by-name/boot:7727104:4c7bc22b540f0b01eb43f8d4b4164a19fcfcee67 EMMC:/dev/block/by-name/recovery 3929088a778a100c6f8bf1664dee9ebeee8940cd 8425472 4c7bc22b540f0b01eb43f8d4b4164a19fcfcee67:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
