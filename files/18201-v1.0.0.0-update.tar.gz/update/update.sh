#!/bin/sh

echo "start update ext partition..."
chmod +x /tmp/update/*.sh
/tmp/update/runled.sh &

#++ kill ipcam & thttpd & umount ext
killall ipcam
killall thttpd

umount /ext
while [ $? -ne 0 ]; do
    echo "try to umount /ext ..."
    sleep 1
    umount /ext
done
#-- kill ipcam & thttpd & umount ext

# write update to ext partition
dd if=/tmp/update/ext.jffs2 of=/dev/block/mtdblock3

if [ $? -eq 0 ]; then
    echo "update done !"

    # stop led run
    killall runled.sh

    # turn on green led
    /tmp/update/led.sh 0 1 0

#   sleep 3 && reboot -f
else
    echo "update failed !"

    # stop led run
    killall runled.sh

    # turn on red led
    /tmp/update/led.sh 1 0 0
fi

