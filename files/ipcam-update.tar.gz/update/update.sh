#!/bin/sh

echo "start update ..."
chmod +x /tmp/update/*.sh
/tmp/update/runled.sh &

#++ kill ipcam & thttpd & umount ext
killall watchdog.sh ipcam thttpd

if [ ! -d "/tmp/update/app" ]; then
umount /ext
while [ $? -ne 0 ]; do
    echo "try to umount /ext ..."
    sleep 1
    umount /ext
done
fi
#-- kill ipcam & thttpd & umount ext

RESULT_1=0
RESULT_2=0
RESULT_3=0
RESULT_4=0

# write update to ext partition
if [ -d "/tmp/update/app" ]; then
    cp -rp /tmp/update/app/* /ext/
    RESULT_1=$?
fi

if [ -f "/tmp/update/ext.jffs2" ]; then
    /tmp/update/flash_erase /dev/mtd/mtd3 0 0
    RESULT_1=$?
    /tmp/update/nandwrite -p /dev/mtd/mtd3 /tmp/update/ext.jffs2
    RESULT_2=$?
fi

if [ -f "/tmp/update/system.sqfs.xz" ]; then
    /tmp/update/flash_erase /dev/mtd/mtd2 0 0
    RESULT_3=$?
    /tmp/update/nandwrite -p /dev/mtd/mtd2 /tmp/update/system.sqfs.xz
    RESULT_4=$?
fi

if [ $RESULT_1 -eq 0 -a $RESULT_2 -eq 0 -a $RESULT_3 -eq 0 -a $RESULT_4 -eq 0 ]; then
    echo "update done !"

    # stop led run
    killall runled.sh

    # turn on green led
    /tmp/update/setled.sh 0 1 0

    rm -rf /data/ipcam/ipcam.ini
    sync

    if [ ! -f "/tmp/update/sdupdate" ]; then
        sleep 3 && reboot -f
    fi
else
    echo "update failed !"

    # stop led run
    killall runled.sh

    # turn on red led
    /tmp/update/setled.sh 1 0 0
fi

